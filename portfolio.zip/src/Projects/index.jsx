export const pro_data=[
    {
        title:"Canteen Website",desc:"Online Canteen Manangement System.Both FrontEnd and BackEnd Integrated",image:rest,type:"personal"
    },
    {
        title:"Resume Builder",desc:"Classic Example of Redux Toolkit and Firebase Integration",image:resume,type:"personal"
    },
    {
        title:"Instagram Clone",desc:"Instagram Reels clone with the use of firebase, redux and intersection API",image:insta,type:"personal"
    },
    {
        title:"It Firm Webstite",desc:"A React based Website for DigiSoulTech Pvt Ltd.",image:company,type:"client"
    },
    {
        title:"Shopping Cart",desc:"Redux Toolkit",image:shop,type:"personal"
    },
    {
        title:"Hospital Website",desc:"Developed a React Website for Shre Ganesh Eye Hospital",image:hospital,type:"client"
    }
]